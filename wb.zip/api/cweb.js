// File: /pages/api/cweb.js
import dns from "dns/promises";

export default async function handler(req, res) {
  let { domain } = req.query;
  if (!domain) {
    return res.status(400).json({ error: "Domain tidak diberikan" });
  }

  try {
    // Bersihkan input: buang http://, https://, dan path
    domain = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "");

    // Resolve domain ke IP
    const { address } = await dns.lookup(domain);

    // Query ipinfo dengan IP
    const ipinfoRes = await fetch(`https://ipinfo.io/${address}?token=20bfc02a8c644e`);
    if (!ipinfoRes.ok) {
      throw new Error(`ipinfo error: ${ipinfoRes.status}`);
    }
    const data = await ipinfoRes.json();

    return res.status(200).json({
      ip: data.ip || address || "N/A",
      hostname: data.hostname || "N/A",
      isp: data.org ? data.org.split(" ")[1] : "N/A",
      org: data.org || "N/A",
      country: data.country || "N/A",
      region: data.region || "N/A",
      city: data.city || "N/A",
      timezone: data.timezone || "N/A",
      postal: data.postal || "N/A",
      loc: data.loc || "N/A"
    });

  } catch (error) {
    console.error("Primary API gagal:", error);

    // === FALLBACK KE ip-api.com (gratis, tanpa token) ===
    try {
      const fallbackRes = await fetch(`http://ip-api.com/json/${domain}`);
      const fb = await fallbackRes.json();

      if (fb.status === "fail") {
        return res.status(500).json({ error: "Gagal ambil data (fallback)" });
      }

      return res.status(200).json({
        ip: fb.query || "N/A",
        hostname: fb.reverse || "N/A",
        isp: fb.isp || "N/A",
        org: fb.org || "N/A",
        country: fb.country || "N/A",
        region: fb.regionName || "N/A",
        city: fb.city || "N/A",
        timezone: fb.timezone || "N/A",
        postal: fb.zip || "N/A",
        loc: `${fb.lat},${fb.lon}` || "N/A"
      });
    } catch (e) {
      console.error("Fallback API juga gagal:", e);
      return res.status(500).json({ error: "Gagal total ambil data" });
    }
  }
}